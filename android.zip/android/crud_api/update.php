<?php
include 'connection.php';

$complaint_id=$_POST['id'];
$remark=$_POST['instructions'];
$assignee=$_POST['asignee'];

$query_user = mysqli_query($con, "Select id from users_for_app WHERE name = '$assignee' limit 1");
$row_user=mysqli_fetch_assoc($query_user);

$assignee_id=$row_user['id'];
//$query = mysqli_query($con, "UPDATE data SET uid = '$uid', name = '$name', phone = '$phone', address = '$address' WHERE id = '$id' ");


$query=mysqli_query($con,"INSERT into complaint_remark_details (
complaint_id,
complaint_status,
remark,
assignee_id,
remark_dt,
display) values 
(
'$complaint_id',
2,
'$remark',
'$assignee_id',
NOW(),
'Y'
)");

if($query){
	$query_update=mysqli_query($con,"UPDATE complaint_details SET complaint_status=2 where id=".$complaint_id);
	
  $response['success'] = 'true';
  $response['message'] = 'Grievance is Assigned to User';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Not Assigned due to Server Error ';
}

echo json_encode($response);
?>
