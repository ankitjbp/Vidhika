<?php
include 'connection.php';

$mobile=$_POST['phone'];

/*
$query = mysqli_query($con, "SELECT cd.*
FROM users_for_app ufa
LEFT JOIN complaint_details cd ON cd.district_id = ufa.current_location
LEFT JOIN complaint_remark_details crd ON crd.assignee_id = ufa.id
WHERE ufa.mobile_number = ".$mobile."
AND cd.id IS NOT NULL
AND cd.complaint_status=2"); 
*/

/* $query = mysqli_query($con, "SELECT cd. *
FROM complaint_details cd
LEFT JOIN (
SELECT crd. *
FROM users_for_app ufa
LEFT JOIN complaint_remark_details crd ON crd.assignee_id = ufa.id
WHERE crd.id IS NOT NULL
AND ufa.mobile_number = ".$mobile."
)t ON cd.id = t.complaint_id
WHERE cd.complaint_status =2");
*/


$query = mysqli_query($con,"SELECT cd.*
FROM complaint_remark_details crd
LEFT JOIN complaint_details cd ON crd.complaint_id = cd.id
LEFT JOIN users_for_app ufa ON crd.assignee_id = ufa.id
WHERE crd.assignee_id IS NOT NULL
AND ufa.id IS NOT NULL
AND cd.complaint_status =2
AND ufa.mobile_number='".$mobile."'");


//echo "SELECT cd.*
//FROM users_for_app ufa
//LEFT JOIN complaint_details cd ON cd.district_id = ufa.current_location
//WHERE ufa.mobile_number = ".$mobile."
//AND cd.id IS NOT NULL";



$data = array();
$qry_array = array();
$i = 0;
$total = mysqli_num_rows($query);
while ($row = mysqli_fetch_assoc($query)) {
   // print_r($row);
  $data['id'] = $row['id'];
  $data['name'] = $row['user_name'];
  $data['number'] = $row['mobile_number'];
  $data['address'] = $row['address'];
  $data['details'] =  $row['text'];
  $qry_array[$i] = $data;
  $i++;
}

if($query){
	  $response['total'] = $total;
  $response['data'] = $qry_array;
  $response['success'] = 'true';
  if($total>0)
  $response['message'] = 'Number of assigned Grievances to me ='.$total;
else 
	$response['message'] = 'No Any grievances assigned to me';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Data Loading Failed';
}

echo json_encode($response);
?>
