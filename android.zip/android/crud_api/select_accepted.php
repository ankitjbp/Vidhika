<?php
include 'connection.php';

$mobile=$_POST['phone'];

$query = mysqli_query($con, "SELECT cd.*
FROM users_for_app ufa
LEFT JOIN complaint_details cd ON cd.district_id = ufa.current_location
WHERE ufa.mobile_number = ".$mobile."
AND cd.id IS NOT NULL
AND cd.complaint_status=4");

//echo "SELECT cd.*
//FROM users_for_app ufa
//LEFT JOIN complaint_details cd ON cd.district_id = ufa.current_location
//WHERE ufa.mobile_number = ".$mobile."
//AND cd.id IS NOT NULL";



$data = array();
$qry_array = array();
$i = 0;
$total = mysqli_num_rows($query);
while ($row = mysqli_fetch_assoc($query)) {
   // print_r($row);
  $data['id'] = $row['id'];
  $data['name'] = $row['user_name'];
  $data['number'] = $row['mobile_number'];
  $data['address'] = $row['address'];
  $data['details'] =  $row['text'];
  $qry_array[$i] = $data;
  $i++;
}

if($query){
  $response['success'] = 'true';
 $response['total'] = $total;
 
 if($total==0){
	   $response['message'] = 'Data not available';
 } else
	 {
  $response['message'] = 'Solution Accepted for grievances  ='.$total;	 
 }
 
  $response['data'] = $qry_array;
}else{
  $response['success'] = 'false';
  $response['message'] = 'Data Loading Failed';
}

echo json_encode($response);
?>
