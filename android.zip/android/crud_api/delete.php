<?php
include 'connection.php';

$id = $_POST['id'];

$query = mysqli_query($con, "update complaint_details SET complaint_status=5 where id= '$id'");

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Grievance Withdrawn Successfully';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Withdrwal of Grievance Failed';
}

echo json_encode($response);
?>
