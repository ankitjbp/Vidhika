<?php
include 'connection.php';

$id = $_POST['id'];

$query = mysqli_query($con, "update complaint_details SET complaint_status=1 where id= '$id'");

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Grievance Resubmitted Successfully';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Technical Error';
}

echo json_encode($response);
?>
