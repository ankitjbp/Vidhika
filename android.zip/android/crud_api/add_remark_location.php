<?php
include 'connection.php';

/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/


$uid = $_POST['uid'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$details = $_POST['details'];
$district = $_POST['district'];
$help_type = $_POST['help_type'];

$phone = $_POST['phone'];
$lat = $_POST['lat'];
$long = $_POST['long'];
$remark = $_POST['remark'];


$response = array();
$response['success'] = 'true';
$response['message'] = 'Location to saved for  - '.$_POST['phone']." for ".$_POST['lat']." and ".$_POST['long'];

//echo json_encode($response);

$name = preg_replace('/[^A-Za-z0-9\. -]/', '', $name);
$address = preg_replace('/[^A-Za-z0-9\. -]/', '', $address);
$details = preg_replace('/[^A-Za-z0-9\. -]/', '', $details);


$result_user= mysqli_query($con,"SELECT * FROM users_for_app where mobile_number = '".$phone."'");
$row_user= mysqli_fetch_assoc($result_user);

/*
$query_duplicate="Select * from complaint_details where email='$uid' and user_name='$name' and mobile_number='$phone'
 and district_id= '$row_dist[id_no]'
 and address = '$address'
 and text='$details'
";

$result_duplicate=mysqli_query($con,$query_duplicate);
// $row_duplicate=mysqli_fetch_assoc($con,$result_duplicate); 

$count_entry = mysqli_num_rows ( $result_duplicate );


// $query = mysqli_query($con, "INSERT INTO data (uid, name, phone, address,details,created_at) VALUES ('$uid','$name','$phone','$address','$details',NOW())");
if($count_entry>0){
	
  $response['success'] = 'false';
  $response['message'] = 'location  is already marked by user';
}
else {
*/

$response = array();

$query = mysqli_query($con, "INSERT INTO user_location_remark
(user_id,remark,latitude,longitude,remark_dt,display)
VALUES ('$row_user[id]','$remark','$lat','$long',NOW(),1)");
if($query){
  $response['success'] = 'true';
  $response['message'] = 'Location Marked Successfully';

}else{
  $response['success'] = 'false';
  $response['message'] = ' Not sumitted due to some technical issue.';

}


echo json_encode($response);

exit();

?>
