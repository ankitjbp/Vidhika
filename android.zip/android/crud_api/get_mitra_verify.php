<?php
include 'connection.php';



$phone = $_POST['phone'];
$address = $_POST['address'];
$response = array();
$query = mysqli_query($con, "INSERT INTO mpslsa_mitra_verification (id, phone) VALUES (null,'$phone')");

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Request Submitted to MPSLSA';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Request Failed';
}

echo json_encode($response);
?>
