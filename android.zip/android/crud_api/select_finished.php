<?php
include 'connection.php';
$mobile=$_POST['name'];
$query = mysqli_query($con, "SELECT * FROM complaint_details where mobile_number=".$mobile ." and complaint_status = 3 order by rcv_dt desc");
$data = array();
$qry_array = array();
$i = 0;
$total = mysqli_num_rows($query);
while ($row = mysqli_fetch_array($query)) {
  $data['id'] = $row['id'];
  $data['uid'] = $row['email'];
  $data['name'] = $row['user_name'];
  $data['phone'] = $row['mobile_number'];
  $data['address'] = $row['address'];
  $data['details'] = $row['text'];
  if($row['complaint_status']==1){
  $data['status'] = 'Grievance is Pending at DLSA';	  
  }
  else   if($row['complaint_status']==2){
  $data['status'] = 'Grievance is Asigned';	  
  }
  else   if($row['complaint_status']=3){
  $data['status'] = 'Grievance is Resolve by Assinee, kindly verify at your end.';	  
  }



  $qry_array[$i] = $data;
  $i++;
}

if($query){
$total = mysqli_num_rows($query);
  $response['success'] = 'true';
  if($total>0)
  $response['message'] = 'Number of Resolved Grievances resolved ='.$total;
else 
	$response['message'] = 'No Grievance Solved to be shown';

  $response['total'] = $total;
  $response['data'] = $qry_array;
}else{
  $response['success'] = 'false';
  $response['message'] = 'Data Loading Failed';
}

echo json_encode($response);
?>
