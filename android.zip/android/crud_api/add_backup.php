<?php
include 'connection.php';

$uid = $_POST['uid'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$details = $_POST['details'];

$response = array();
$query = mysqli_query($con, "INSERT INTO data (uid, name, phone, address,details,created_at) VALUES ('$uid','$name','$phone','$address','$details',NOW())");

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Grievance Registered Successfully';
}else{
  $response['success'] = 'false';
  $response['message_'] = ' Not sumitted due to some technical issue.';
  $response['message'] = "INSERT INTO data (uid, name, phone, address,details,created_at) VALUES ('$uid','$name','$phone','$address','$details',NOW())";
  
}

echo json_encode($response);
?>
