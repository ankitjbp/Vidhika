<?php
include 'connection.php';
$mobile=$_POST['phone'];
$query_location = mysqli_query($con, "SELECT current_location FROM users_for_app where  mobile_number=".$mobile);
$row_location = mysqli_fetch_array($query_location);


$query = mysqli_query($con, "SELECT * FROM users_for_app where user_type <6 and current_location=".$row_location['current_location']." and mobile_number !=".$mobile);


$data = array();
$qry_array = array();
$i = 0;
$total = mysqli_num_rows($query);
while ($row = mysqli_fetch_array($query)) {
  $data['name'] = $row['name'];
  $data['id'] = $row['id'];
  $qry_array[$i] = $data;
  $i++;
}

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Data Loaded Successfully';
  $response['total'] = $total;
  $response['data'] = $qry_array;
}else{
  $response['success'] = 'false';
  $response['message'] = 'Data Loading Failed';
}

echo json_encode($response);
?>
