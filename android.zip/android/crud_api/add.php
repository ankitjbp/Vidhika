<?php
include 'connection.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



$uid = $_POST['uid'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$details = $_POST['details'];
$district = $_POST['district'];
$help_type = $_POST['help_type'];


$name = preg_replace('/[^A-Za-z0-9\. -]/', '', $name);
$address = preg_replace('/[^A-Za-z0-9\. -]/', '', $address);
$details = preg_replace('/[^A-Za-z0-9\. -]/', '', $details);


$result_help= mysqli_query($con,"SELECT * FROM assistance_master where name like '%".$help_type."%'");
$row_help= mysqli_fetch_assoc($result_help);


$result_dist= mysqli_query($con,"select id_no from state where Name='".$district."'");
$row_dist= mysqli_fetch_assoc($result_dist);


$query_duplicate="Select * from complaint_details where email='$uid' and user_name='$name' and mobile_number='$phone'
 and district_id= '$row_dist[id_no]'
 and address = '$address'
 and text='$details'
";

$result_duplicate=mysqli_query($con,$query_duplicate);
// $row_duplicate=mysqli_fetch_assoc($con,$result_duplicate);

$count_entry = mysqli_num_rows ( $result_duplicate );


$response = array();
// $query = mysqli_query($con, "INSERT INTO data (uid, name, phone, address,details,created_at) VALUES ('$uid','$name','$phone','$address','$details',NOW())");
if($count_entry>0){
	
  $response['success'] = 'false';
  $response['message'] = 'Grievance is already registered';
}
else {
$query = mysqli_query($con, "INSERT INTO complaint_details
(email,user_name,mobile_number,district_id,address,text,rcv_dt,assistance_id,complaint_status,display)
VALUES ('$uid','$name','$phone','$row_dist[id_no]','$address','$details',NOW(),'$row_help[id]',1,1)");
if($query){
  $response['success'] = 'true';
  $response['message'] = 'Grievance Registered Successfully at DLSA - '.$district." for ".$help_type ;
}else{
  $response['success'] = 'false';
  $response['message'] = ' Not sumitted due to some technical issue.';
}

}


echo json_encode($response);
?>
