<?php
include 'connection.php';

$uid = $_POST['uid'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$details = $_POST['details'];
$lat_val = $_POST['lat_val'];
$long_val = $_POST['long_val'];
$response = array();

$start = microtime(true);
$dir = $_SERVER['DOCUMENT_ROOT']."/android/crud_api/images/";

if( isset($_FILES['image']['name']) )

{

    $file_name = time().basename($_FILES['image']['name']);

    

    $extension = strtolower(pathinfo($file_name,PATHINFO_EXTENSION));



        if ($extension == 'png' || $extension == 'jpg' || $extension == 'jpeg') {



            if($_FILES["image"]["size"] < 4000001){

                

                $file = $dir.$file_name;

                

                if( move_uploaded_file($_FILES['image']['tmp_name'], $file) )

                {

                    $arr = array(

                    'status'=>1, 

                    'message'=>"File Uploaded",

                    'file_name'=>$file_name

                    );

                }

                else

                {

                    $response['error']="Something Went Wrong Please Retry";

                }

                

            }

            else

            {

                $response['error']="File size cant exceed 4 MB";

            }  

        }

        else

        {
            $response['error']="Only .png, .jpg and .jpeg format are accepted";
        }


}

else{

    $response['error']="Please try Post Method";

}



$query = mysqli_query($con, "INSERT INTO data (uid, name, phone, address,details,attachment,lat_val,long_val created_at) VALUES ('$uid','$name','$phone','$address','$details','$file_name','$lat_val','$long_val',NOW())");

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Grievance Registered Successfully'.$response['error'];
}else{
  $response['success'] = 'false';
  $response['message_'] = ' Not sumitted due to some technical issue.';
  $response['message'] = "INSERT INTO data (uid, name, phone, address,details,attachment, created_at) VALUES ('$uid','$name','$phone','$address','$details','$file_name',NOW()) ".$response['error'];
  
}

echo json_encode($response);
?>
