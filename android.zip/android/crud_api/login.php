<?php
include 'connection.php';

$phone = $_POST['phone'];
$password = $_POST['password'];

// $password="123456";

$response = array();
$query_result = mysqli_query($con, "Select * from users_for_app where mobile_number=$phone and 
password='".$password."'");

$row = mysqli_fetch_assoc($query_result);
if($row[id]>0){
  $response['success'] = 'true';
  $response['message'] = 'Login User Successfully';
  $response['user_mobile'] = $row['mobile_number'];
  if($row['user_type']<=5)
  {
	  $response['user_type'] = 'admin';
  }
  else {
	  $response['user_type'] = 'user';
  }
} else
{
  $response['success'] = 'false';
  $response['message'] = 'Wrong credentials';
//  $response['message'] = "INSERT INTO data (uid, name, phone, address,details,created_at) VALUES ('$uid','$name','$phone','$address','$details',NOW())";
  
}

echo json_encode($response);
?>
