<?php
/*
$host = "localhost";
$user = "ankit";
$pass = "ankit123@";
$db = "grievance";
*/

$host = "localhost";
$user = "root";
$pass = "new@password5";
$db = "grievance";



$con = mysqli_connect($host,$user,$pass, $db);

// if($con){
//   echo "Koneksi Berhasil";
// }else{
//   echo "gagal";
// }



 ?>
