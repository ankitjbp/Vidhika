<?php
include 'connection.php';
$mobile=$_POST['phone'];
$query = mysqli_query($con, "SELECT * FROM users_for_app where mobile_number=".$mobile." order by name ");
$data = array();
$qry_array = array();
$i = 0;
$total = mysqli_num_rows($query);
while ($row = mysqli_fetch_array($query)) {
  $data['name'] = $row['name'];
  $data['id'] = $row['id'];
  $data['mobile_number'] = $row['mobile_number'];
  $qry_array[$i] = $data;
  $i++;
}

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Data Loaded Successfully';
  $response['total'] = $total;
  $response['data'] = $qry_array;
}else{
  $response['success'] = 'false';
  $response['message'] = 'Data Loading Failed';
}

echo json_encode($response);
?>
