<?php
include 'connection.php';

$id = $_POST['id'];

$query = mysqli_query($con, "update complaint_details SET complaint_status=4 where id= '$id'");

if($query){
  $response['success'] = 'true';
  $response['message'] = 'Grievance Solution Accepted by You';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Technical Error Occured';
}

echo json_encode($response);
?>
