<?php
include 'connection.php';



$name = $_POST['name'];
$mobile_number = $_POST['mobile_number'];
$user_type = $_POST['user_type'];
$district = $_POST['district'];

$response = array();
$query_district = mysqli_query($con, "Select id_no from state where Name like '$district'");
$row_district=  mysqli_fetch_array($query_district);
$district_id=$row_district['id_no'];

$query_des = mysqli_query($con, "Select id from user_type where title = '$user_type'");
$row_des=  mysqli_fetch_array($query_des);
$des=$row_des['id'];


// echo "INSERT INTO users_for_app (id, name,user_type,mobile_number,current_location,display) VALUES (null,'$name',$des,'$mobile_number','$district_id',1)";
$query = mysqli_query($con, "INSERT INTO users_for_app (id, name,user_type,mobile_number,current_location,display) VALUES (null,'$name',$des,'$mobile_number','$district_id','Y')");


if($query){
  $response['success'] = 'true';
  $response['message'] = 'Request Submitted to MPSLSA';
}else{
  $response['success'] = 'false';
  $response['message'] = 'Request Failed at Server';
  $response['message'] = "INSERT INTO users_for_app (id, name,user_type,mobile_number,current_location,display) VALUES (null,'$name',$des,'$mobile_number','$district_id','Y')";
}

echo json_encode($response);
?>
